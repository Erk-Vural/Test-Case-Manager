# Postgresql settings
dbName = 'test-case-mgmt-db'
dbUser = 'bvural'
dbPassword = '1234'
dbHost = 'localhost'
dbPort = '5432'

# admin account / admin account info is stored in 'auth_user' table
adminName = 'test'
adminMail = 'test@mail.com'
adminPassword = 'test'